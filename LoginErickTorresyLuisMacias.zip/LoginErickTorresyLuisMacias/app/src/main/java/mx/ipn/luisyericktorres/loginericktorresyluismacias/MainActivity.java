package mx.ipn.luisyericktorres.loginericktorresyluismacias;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText usuario, contra;
    TextView error;
    String cadena1, cadena2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usuario = (EditText) findViewById(R.id.usuario);
        contra = (EditText) findViewById(R.id.contra);
        error= (TextView) findViewById(R.id.error);
    }


    public void comprueba(View v){

        cadena1=usuario.getText().toString().trim();
        cadena2=contra.getText().toString().trim();



        if(cadena1.equals("eoropezag@ipn.mx") && cadena2.equals("laboratorio")){

            Intent envia = new Intent(this, Main2Activity.class);
            finish();
            startActivity(envia);

        }
        else{
            error.setText("Usuario y/o contraseña incorrectos");
        }

    }





}
